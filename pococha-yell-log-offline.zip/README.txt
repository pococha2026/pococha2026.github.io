Pococha1012 エール記録 オフライン版
index.htmlをブラウザーで開いてください。端末やブラウザーによって保存が制限されるため、定期的にバックアップを保存してください。
Web版: https://pococha2026.github.io/yell-log.html
